# EOL: Threat Intel Receivers

I don't maitain these receivers anymore. Most of them were written for Python 2 and the project maintainers change their APIs very frequently.

I'll leave them here for you as a template for your own solutions.
